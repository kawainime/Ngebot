# uncompyle6 version 3.7.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 3.7.2 (default, Mar 20 2019, 15:02:54) 
# [GCC 8.2.0]
# Embedded file name: C:\Scripts\excute\Tools\__init__.py
#Cracked By Black_Phish
pass
# okay decompiling __init__.pyc
