# ae-bot
Automatic exploiter vulnerability scanner tool 👽
Install Python 2.7 Run Other Tools

<a href="https://wa.me/+6282113409538"><img src="https://i.ibb.co/8s92x6y/alien1337.png" width="700" alt="Image"></a>

Module :

``-pip3 install -r requirements.txt``

[AE Bot V1  - Only work for python 2.7]
``` 
Module :
-pkg install bash 
-pip install request
-pip install requests
-pip install colorama
-pip install bs4
-pip install tldextract
``` 
Thanks you~

