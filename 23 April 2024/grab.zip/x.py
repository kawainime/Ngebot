import os
import subprocess
from colorama import Fore, Style
from prompt_toolkit import prompt
from prompt_toolkit.styles import Style as PTStyle

pt_style = PTStyle.from_dict({
    'prompt': 'bg:ansiblue fg:white bold',
})

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main_menu():
    clear_screen()
    print(Fore.MAGENTA + "╭─────────────────────────╮")
    print("│        Main Menu        │")
    print("├─────────────────────────┤")
    print(Fore.CYAN + "│ 1. AutoXploiter Bot     │")
    print("│ 2. Grabber By EXT       │")
    print(Fore.MAGENTA + "│ 3. MASS Subdomain Finder│")
    print("│ 4. MASS Reverse IP      │")
    print(Fore.CYAN + "│ 5. Grabber By KeyWord   │")
    print("│ 6. GRABBER BY PAGE V1   │")
    print("│ 7. GRABBER BY A-Z 0-9   │")
    print(Fore.CYAN + "│ 8. Grab Domain Per Sec  │")
    print(Fore.CYAN + "│ 9. GRABBER BY PAGE V2   │")
    print(Fore.CYAN + "│ 10.GRABBER BY ANGKA     │")
    print("╰─────────────────────────╯")
    print(Fore.WHITE + "  [ Tools by Chris ]")
    print(Style.RESET_ALL)
    choice = prompt('PILIH MENU: ', style=pt_style)

    if choice == '1':
        current_directory = os.path.dirname(os.path.abspath(__file__))
        file_name = input("list: ")
        file_path = os.path.join(current_directory, file_name)
        if os.path.isfile(file_path):
            # Pindah ke direktori /tools/
            os.chdir('tools')
            # Jalankan rsf.py dengan argumen file list
            os.system(f"python rsf.py {file_path}")
            # Kembalikan ke direktori awal
            os.chdir(current_directory)
        else:
            print(f"File {file_name} tidak ditemukan.")
    elif choice == '2':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        grab1_script = os.path.join(tools_directory, 'grab1.py')
        
        if os.path.isfile(grab1_script):
            subprocess.run(['python', grab1_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '3':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        subfind_script = os.path.join(tools_directory, 'subfind.py')
        
        if os.path.isfile(subfind_script):
            subprocess.run(['python', subfind_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '4':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        rev_script = os.path.join(tools_directory, 'rev.py')
        
        if os.path.isfile(rev_script):
            subprocess.run(['python', rev_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '5':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        grab1_script = os.path.join(tools_directory, 'grab2.py')
        
        if os.path.isfile(grab1_script):
            subprocess.run(['python', grab1_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '6':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        grab1_script = os.path.join(tools_directory, 'grab3.py')
        
        if os.path.isfile(grab1_script):
            subprocess.run(['python', grab1_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '7':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        grab1_script = os.path.join(tools_directory, 'grab4.py')
        
        if os.path.isfile(grab1_script):
            subprocess.run(['python', grab1_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '8':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        grab1_script = os.path.join(tools_directory, 'grab5.py')
        
        if os.path.isfile(grab1_script):
            subprocess.run(['python', grab1_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '9':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        grab1_script = os.path.join(tools_directory, 'grab6.py')
        
        if os.path.isfile(grab1_script):
            subprocess.run(['python', grab1_script], cwd=tools_directory)
        else:
            print("error tools")
    elif choice == '10':
        tools_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        grab1_script = os.path.join(tools_directory, 'grab7.py')
        
        if os.path.isfile(grab1_script):
            subprocess.run(['python', grab1_script], cwd=tools_directory)
        else:
            print("error tools")
    else:
        print(Fore.RED + "Pilihan tidak valid.")
        print(Style.RESET_ALL)

if __name__ == "__main__":
    main_menu()