# Mass XMLRPC Wordpress Brute
XML-RPC &amp; WP-LOGIN Wordpress Brute Force With Awesome Features

## Features
```
1. Use Custom SSL
2. Use Dict Password List
3. Multi-Thread
4. Auto Check HTTP/HTTPS
5. Auto Get Username
6. For more you can check yourself
```

## Installation
Make sure you have been install python3+ on you machine
```
pip install colorama requests
git clone https://github.com/fooster1337/Mass-XMLRPC-Wordpress-Brute/
cd Mass-XMLRPC-Wordpress-Brute
python3 brute.py
```

## Credits
Author : <a href="https://t.me/@GrazzMean">fooster1337</a>


